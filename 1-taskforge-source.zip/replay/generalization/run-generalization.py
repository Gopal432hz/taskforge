"""Local generalization run: selected upstream changes, same mining/emission/verifier path."""
from pathlib import Path
import sys, json, subprocess, os, tarfile, shutil, ast, re
ROOT=Path(__file__).resolve().parent
FACTORY=ROOT.parent/'factory'
sys.path.insert(0,str(FACTORY))
import mine, emit
REPO=ROOT.parent/'source-click'
if not REPO.exists():
    subprocess.run(['git','clone','--quiet',str(ROOT.parent/'click-history.bundle'),str(REPO)],check=True)
    subprocess.run(['git','-C',str(REPO),'remote','set-url','origin','https://github.com/pallets/click'],check=True)
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--python',default=sys.executable);args=parser.parse_args()
PYTHON=Path(os.path.abspath(args.python))
SELECTED=['271effb3d96da5575eb527216ce3552bd7628fab','90a2973f85fffc4d8a20effb2bcdff3f394c5e62']

def new_api_contract(spec):
    """Extract added public API docs from the feature tree, without per-task text."""
    cand=next(c for c in mine.candidates(str(REPO)) if c['commit']==spec['_mined_from'])
    symbols,params=mine.api_expansion(str(REPO),cand['commit'],cand['src_files'])
    reqs=['Implement '+spec['feature_title']+'.']
    for path in cand['src_files']:
        text=mine.git(str(REPO),'show',cand['commit']+':'+path)[1]
        tree=ast.parse(text)
        for node in tree.body:
            members=[(node.name,node)] if isinstance(node,(ast.FunctionDef,ast.ClassDef)) else []
            if isinstance(node,ast.ClassDef):
                members += [(node.name+'.'+n.name,n) for n in node.body if isinstance(n,ast.FunctionDef)]
            for name,n in members:
                if name not in symbols and not any(v.startswith(name+'(') for v in params): continue
                doc=ast.get_docstring(n) or ''
                # Strip version metadata; retain behavior and parameter text.
                doc=re.split(r'\n\s*\.\. version',doc)[0]
                reqs.append(name+': '+re.sub(r'\s+',' ',doc).strip())
    reqs.append('Keep the selected unchanged base regression tests passing. The supplied feature checks are minimum acceptance checks, not exhaustive requirements.')
    return reqs

allc=mine.candidates(str(REPO)); results=[]
for commit in SELECTED:
    cand=next(c for c in allc if c['commit']==commit)
    spec=mine.spec_from(str(REPO),cand,allc.index(cand),['tests/test_basic.py'])
    # This is generic extraction, not a per-task reviewed override.
    reqs=new_api_contract(spec)
    spec['requirements']=reqs
    spec['generated_requirements']=reqs
    spec['requirements_origin']='automatic public API doc extraction; human selection of upstream changes'
    (ROOT/(spec['id']+'.json')).write_text(json.dumps(spec,indent=2))
    emit.emit(spec,str(ROOT/'generated'))
    pkg=ROOT/'generated'/spec['id']; sim=ROOT/'runtime'/spec['id']
    if sim.exists():shutil.rmtree(sim)
    (sim/'app').mkdir(parents=True)
    with tarfile.open(pkg/'environment/repo.tar.gz') as t:
        for m in t.getmembers():
            if m.name.startswith('/') or '..' in Path(m.name).parts or m.issym() or m.islnk():raise ValueError('unsafe archive')
        t.extractall(sim/'app')
    shutil.copytree(pkg/'tests',sim/'tests');(sim/'scratch').mkdir()
    script=(pkg/'tests/test.sh').read_text().replace('/logs',str(sim/'logs')).replace('/app',str(sim/'app')).replace('/tests/feature',str(sim/'tests/feature')).replace('/tmp/absent.txt',str(sim/'scratch/absent.txt')).replace('/tmp/orig',str(sim/'scratch/orig'))
    (sim/'verifier.sh').write_text(script);(sim/'bin').mkdir()
    (sim/'bin/pytest').write_text('#!/bin/sh\nexec '+str(PYTHON)+' -m pytest "$@"\n');(sim/'bin/pytest').chmod(0o755)
    env=dict(os.environ,PATH=str(sim/'bin')+':'+os.environ['PATH'],PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
    states={}
    for state,expected in [('base',0),('patched',1)]:
        if state=='patched':subprocess.run(['git','apply',str(pkg/'solution/reference.patch')],cwd=sim/'app',check=True)
        p=subprocess.run(['bash',str(sim/'verifier.sh')],env=env,capture_output=True,text=True,timeout=120)
        (ROOT/(spec['id']+'.'+state+'.txt')).write_text(p.stdout+p.stderr)
        reward=json.loads((sim/'logs/verifier/reward.json').read_text());states[state]=reward
        print(spec['id'],state,reward,flush=True)
        print('\n'.join(l for l in p.stdout.splitlines() if 'passed' in l or 'failed' in l or 'error' in l),flush=True)
        if reward['reward']!=expected or reward['regression']!=1:raise RuntimeError('Unexpected verifier state, see raw logs')
    results.append({'id':spec['id'],'base_commit':spec['base_commit'],'change_commit':commit,'requirements':reqs,'states':states})
(ROOT/'generalization-results.json').write_text(json.dumps({'scope':'Fresh mining, automatic API-doc requirements extraction and emission for two human-selected Click commits. Local path-remapped verification only. No fresh API call, install, image build or hosted use.','runtime':subprocess.check_output([str(PYTHON),'-c','import sys,pytest;print(sys.version.split()[0],pytest.__version__)'],text=True).strip(),'results':results},indent=2))
