"""Model-free requirement prose: turn a mined TaskSpec into agent-grade requirements.

Deterministic templates from diff facts: commit message, added/changed public
symbols, changed files, and the behavior the commit's own tests assert
(extracted from test function names). No model call; honest, verifiable text.
"""
import re

STOP = {"test", "tests", "when", "with", "that", "this", "from", "have", "has",
        "the", "and", "for", "are", "was", "were", "not", "all", "any", "new"}

def camel_split(name):
    return re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", name).replace("_", " ").lower()

def behavior_phrases(test_names):
    phrases = []
    for n in test_names:
        words = [w for w in n[5:].split("_") if w not in STOP] if n.startswith("test_") else []
        if words:
            phrases.append(" ".join(words))
    return phrases

def _dedupe(xs):
    seen = set(); out = []
    for x in xs:
        if x not in seen:
            seen.add(x); out.append(x)
    return out

def _clean_rst(text):
    """Strip docutils/RST markup to plain text."""
    t = re.sub(r":(?:param|type)\s+(\w+)\s*:", r"\1:", text)
    t = re.sub(r":(?:attr|class|func|meth|mod|ref|data|const|exc):`([^`]+)`", r"\1", t)
    t = t.replace("``", "`")
    return t.strip()

def diff_facts(patch):
    """Deterministic facts from the solution diff: signature and docstring changes."""
    sigs, params, doclines = [], [], []
    lines = patch.splitlines()
    i = 0
    while i < len(lines):
        l = lines[i]
        i += 1
        if not l.startswith("+") or l.startswith("+++"):
            continue
        body = l[1:].strip()
        if re.match(r"(?:async\s+)?def\s+\w+\(", body) or re.match(r"class\s+\w+", body):
            # capture multi-line signatures through the closing "):" or ") ->"
            while not re.search(r"\)\s*(:|->)", body) and i < len(lines):
                nl = lines[i]
                if not nl.startswith("+") or nl.startswith("+++"):
                    break
                i += 1
                body += " " + nl[1:].strip()
            body = re.sub(r"\s+", " ", body)
            if len(body) <= 200:
                sigs.append(body)
        elif body.startswith(":param") or body.startswith(":type"):
            params.append(_clean_rst(body))
        elif body.startswith(('"', "'")) is False and 30 < len(body) < 200 and body[0].isupper() and body.endswith("."):
            doclines.append(_clean_rst(body))
    return _dedupe(sigs), _dedupe(params), _dedupe(doclines)

def requirements(spec):
    if spec.get('generated_requirements'):
        return list(spec['generated_requirements'])
    if spec.get('reviewed_requirements'):
        return list(spec['reviewed_requirements'])
    title = spec["feature_title"].rstrip(".")
    title = title[0].upper() + title[1:] if title else title
    syms = []
    for line in spec["requirements"]:
        if line.startswith("The change introduces: "):
            syms = [s.strip() for s in line[len("The change introduces: "):].split(",")]
    tests = []
    for t in spec["feature_tests"]:
        tests += t.get("test_names", [])
    sigs, params, doclines = diff_facts(spec.get("solution_patch", ""))
    reqs = [
        f"Implement the following capability in the repository at /app: {title}.",
    ]
    if syms:
        reqs.append("The implementation must add or update these public names: "
                    + ", ".join(f"`{s}`" for s in syms) + ".")
    for s in sigs[:6]:
        reqs.append(f"Signature (from the reference change): `{s}`")
    for prm in params[:6]:
        reqs.append(f"Documented behavior: `{prm}`")
    for dl in doclines[:3]:
        reqs.append(f"Intended behavior (reference docs): {dl}")
    for ph in behavior_phrases(tests):
        if len(ph.split()) >= 3:
            reqs.append(f"It must handle: {ph}.")
    reqs.append("All pre-existing tests in the repository must continue to pass unchanged.")
    reqs.append("Keep the change minimal and consistent with the codebase's existing style and structure.")
    return reqs

if __name__ == "__main__":
    import json, sys
    spec = json.load(open(sys.argv[1]))
    print("\n".join("- " + r for r in requirements(spec)))
