"""Stage 3b: mine a repo's own git history for realistic feature-development tasks.

A real feature commit C (parent P) yields a TaskSpec without any model call:
  base_commit      = P
  solution_patch   = C's diff restricted to non-test files
  feature_tests    = test functions/files C added (run in place from C's tree)
  regression_tests = the repo's existing suite at P (in place)
  requirements     = commit message + public symbols the patch adds

This is the strongest no-model generalization: tasks are real feature
developments from the repo's history, so realism is intrinsic.
"""
import json, os, re, subprocess, sys, tempfile
NON_FEATURE = re.compile(r"^(fix|bug|typo|revert|docs?|test|refactor|ci|chore|merge|bump|cleanup|release)", re.I)

def git(repo, *args, inp=None):
    p = subprocess.run(["git", "-C", repo] + list(args), capture_output=True, text=True, input=inp)
    return p.returncode, p.stdout, p.stderr

def added_public_symbols(repo, commit, paths):
    syms = []
    for path in paths:
        rc, diff, _ = git(repo, "show", commit, "--", path)
        added = "\n".join(l[1:] for l in diff.splitlines() if l.startswith("+") and not l.startswith("+++"))
        for m in re.finditer(r"^\s*(?:def|class)\s+([A-Za-z]\w*)", added, re.M):
            if not m.group(1).startswith("_"):
                syms.append(m.group(1))
    return sorted(set(syms))

def candidates(repo, limit=2000, revrange=""):
    rng = [revrange] if revrange else [f"-{limit}"]
    rc, log, _ = git(repo, "log", *rng, "--format=%H %P")
    out = []
    for line in log.splitlines():
        parts = line.split()
        if len(parts) != 2:
            continue  # skip merges/root
        c, p = parts
        rc, names, _ = git(repo, "diff-tree", "--no-commit-id", "--name-only", "-r", c)
        files = [f for f in names.splitlines() if f.strip()]
        if not files:
            continue
        tests = [f for f in files if re.search(r"(^|/)tests?/.*\.py$|test_.*\.py$|.*_test\.py$", f)]
        srcs = [f for f in files if f.endswith(".py") and f not in tests]
        if not srcs or not tests or len(files) > 6:
            continue
        rc, msg, _ = git(repo, "log", "-1", "--format=%s%n%b", c)
        out.append({"commit": c, "parent": p, "src_files": srcs, "test_files": tests,
                    "message": msg.strip()})
    return out

def _test_bodies(src):
    """Map test function name -> source segment, via AST."""
    import ast as _ast
    out = {}
    try:
        tree = _ast.parse(src)
    except SyntaxError:
        return out
    for node in _ast.walk(tree):
        if isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)) and node.name.startswith("test_"):
            seg = _ast.get_source_segment(src, node)
            out[node.name] = seg or ""
    return out


def added_test_names(repo, cand, removed=None):
    """Tests whose body the commit ADDS or MODIFIES (both carry the new behavior contract).
    Tests the commit DELETES are collected into `removed` when a set is passed."""
    names = set()
    removed = removed if removed is not None else set()
    for tf in cand["test_files"]:
        rc_a, src_a, _ = git(repo, "show", f"{cand['commit']}^:{tf}")
        rc_b, src_b, _ = git(repo, "show", f"{cand['commit']}:{tf}")
        a = _test_bodies(src_a) if rc_a == 0 else {}
        b = _test_bodies(src_b) if rc_b == 0 else {}
        for name, body in b.items():
            if name not in a or a[name] != body:
                names.add(name)
        for name in a:
            if name not in b:
                removed.add(name)
    return sorted(names)

def _ast_members(src):
    import ast as _ast
    try:
        tree = _ast.parse(src)
    except SyntaxError:
        return {}, {}
    funcs, classes = {}, set()
    for node in tree.body if hasattr(tree, "body") else []:
        if isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
            args = [a.arg for a in node.args.args] + [a.arg for a in node.args.kwonlyargs]
            funcs[node.name] = set(args)
        elif isinstance(node, _ast.ClassDef):
            classes.add(node.name)
            for sub in node.body:
                if isinstance(sub, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
                    args = [a.arg for a in sub.args.args] + [a.arg for a in sub.args.kwonlyargs]
                    funcs[f"{node.name}.{sub.name}"] = set(args)
    return funcs, classes


def api_expansion(repo, commit, srcs):
    """Public API surface growth: new public functions/classes, or new parameters
    (with defaults implied by the diff being mergeable) on existing public ones."""
    new_syms, new_params = [], []
    for f in srcs:
        # symbols in underscore-prefixed modules (httpx/_urlparse.py) are internal,
        # not public API, regardless of their own naming
        if f.rsplit("/", 1)[-1].startswith("_"):
            continue
        rc_a, sa, _ = git(repo, "show", f"{commit}^:{f}")
        rc_b, sb, _ = git(repo, "show", f"{commit}:{f}")
        if rc_b != 0:
            continue
        fa, ca = _ast_members(sa) if rc_a == 0 else ({}, set())
        fb, cb = _ast_members(sb)
        for name in fb:
            pub = not name.split(".")[-1].startswith("_")
            if name not in fa and pub:
                new_syms.append(name)
            elif name in fa and pub and fb[name] - fa[name]:
                new_params.append(f"{name}({', '.join(sorted(fb[name]-fa[name]))})")
        for name in cb - ca:
            if not name.startswith("_"):
                new_syms.append(name)
    return sorted(set(new_syms)), sorted(set(new_params))


def changelog_mention(repo, commit, message):
    """Find the PR/issue number in the repo changelog; classify by nearest heading."""
    nums = re.findall(r"\(#(\d+)\)|:pr:`(\d+)`|:issue:`(\d+)`", message)
    nums = {n for tup in nums for n in tup if n}
    if not nums:
        return None
    rc, listing, _ = git(repo, "ls-tree", "--name-only", commit)
    cands = [f for f in listing.splitlines() if re.match(r"(?i)changes?(\.rst|\.md|\.txt)?$|changelog", f)]
    for cf in cands:
        rc, text, _ = git(repo, "show", f"{commit}:{cf}")
        if rc != 0:
            continue
        lines = text.splitlines()
        for i, l in enumerate(lines):
            if any(re.search(rf"(#|:pr:`|:issue:`){n}\b", l) for n in nums):
                for j in range(i, max(-1, i - 60), -1):
                    h = lines[j].strip().lower()
                    if h.startswith(("##", "**")) or (j + 1 < len(lines) and set(lines[j + 1].strip()) <= {"-", "=", "~"} and lines[j].strip()):
                        if "add" in h:
                            return ("added", f"{cf}:{i+1} under '{lines[j].strip()}'")
                        if "fix" in h or "bug" in h:
                            return ("fixed", f"{cf}:{i+1} under '{lines[j].strip()}'")
                        if "chang" in h:
                            return ("changed", f"{cf}:{i+1} under '{lines[j].strip()}'")
                        if "remov" in h:
                            return ("removed", f"{cf}:{i+1} under '{lines[j].strip()}'")
                return ("mentioned", f"{cf}:{i+1}")
    return None


def classify_feature(repo, cand, srcs, test_names, removed, added_count):
    """Multi-signal classification. Signals are evidence, not proof; the weakest
    link decides. Returns (klass, reasons)."""
    reasons = []
    msg0 = (cand["message"].splitlines()[0] if cand["message"] else "").strip()
    if NON_FEATURE.match(msg0):
        return "fix", [f"commit message prefix: {msg0[:60]}"]
    syms, params = api_expansion(repo, cand["commit"], srcs)
    if syms:
        reasons.append("new public symbols: " + ", ".join(syms[:5]))
    if params:
        reasons.append("new public parameters: " + ", ".join(params[:5]))
    cl = changelog_mention(repo, cand["commit"], cand["message"])
    if cl:
        reasons.append(f"changelog: {cl[0]} ({cl[1]})")
        if cl[0] in ("fixed",):
            return "fix", reasons
    reasons.append(f"acceptance tests: {added_count} added, {len(test_names)-added_count} modified, {len(removed)} deleted")
    api_growth = bool(syms or params)
    if api_growth and added_count and (not cl or cl[0] in ("added", "mentioned")):
        k = "feature_strong" if (cl and cl[0] == "added") or (syms and params) else "feature"
        return k, reasons
    if api_growth:
        return "feature", reasons
    return "behavior_change", reasons


def spec_from(repo, cand, idx, regression):
    srcs, tests = cand["src_files"], cand["test_files"]
    rc, patch, _ = git(repo, "diff", cand["parent"], cand["commit"], "--", *srcs)
    if rc or not patch.strip():
        return None
    removed = set()
    test_names = added_test_names(repo, cand, removed)
    if not test_names:
        return None
    base_names = set()
    for tf in cand["test_files"]:
        rc_a, src_a, _ = git(repo, "show", f"{cand['commit']}^:{tf}")
        if rc_a == 0:
            base_names |= set(_test_bodies(src_a))
    added_count = sum(1 for n in test_names if n not in base_names)
    klass, kreasons = classify_feature(repo, cand, srcs, test_names, removed, added_count)
    if klass in ("fix", "behavior_change"):
        print(f"  rejected ({klass}): {cand['commit'][:10]} {'; '.join(kreasons)[:120]}")
        return None
    msg_first0 = (cand["message"].splitlines()[0] if cand["message"] else "")
    syms = added_public_symbols(repo, cand["commit"], srcs)
    # legacy gate kept as cheap pre-filter; authoritative classification above
    if NON_FEATURE.match(msg_first0.strip()):
        return None
    # automatic regression selection: pre-existing test files the commit touched; caller default only if none
    touched = [tf for tf in tests if git(repo, "cat-file", "-e", f"{cand['parent']}:{tf}")[0] == 0]
    reg = touched if touched else regression
    msg_first = msg_first0
    tid = re.sub(r"[^a-z0-9]+", "-", msg_first.lower()).strip("-")[:40] or f"task-{idx}"
    reqs = [f"Implement the change described by upstream commit: {msg_first}"]
    if syms:
        reqs.append("The change introduces: " + ", ".join(syms[:8]))
    reqs.append("Behavior added by the commit's own tests must work; existing suite must stay green.")
    return {
        "id": tid,
        "base_repo": repo,
        "base_commit": cand["parent"],
        "language": "python",
        "test_command": "pytest",
        "install_editable": True,
        "python_deps": os.environ.get("MINE_DEPS", "").split() if os.environ.get("MINE_DEPS") else [],
        **({"requirements_file": "requirements/tests.txt"} if git(repo, "cat-file", "-e", f"{cand['parent']}:requirements/tests.txt")[0] == 0 else {}),
        "feature_title": msg_first,
        "requirements": reqs,
        "solution_patch": patch,
        "feature_tests": [{"repo_tests_at": cand["commit"], "repo_paths": tests,
                           "test_names": test_names}],
        "regression_tests": [{"repo_path": r} for r in reg],
        **({"removed_tests": sorted(removed)} if removed else {}),
        "feature_classification": klass,
        "classification_reasons": kreasons,
        "_mined_from": cand["commit"],
    }

if __name__ == "__main__":
    repo, outdir = sys.argv[1], sys.argv[2]
    revrange = os.environ.get("MINE_RANGE", "")
    os.makedirs(outdir, exist_ok=True)
    reg = sys.argv[3].split(",") if len(sys.argv) > 3 else ["tests/test_utils.py"]
    n = 0
    for i, cand in enumerate(candidates(repo, revrange=revrange)):
        s = spec_from(repo, cand, i, reg)
        if not s:
            continue
        json.dump(s, open(os.path.join(outdir, f"mined-{i:03d}.json"), "w"), indent=1)
        n += 1
        if n >= int(os.environ.get("MINE_MAX", "10")):
            break
    print("mined", n, "candidates")
