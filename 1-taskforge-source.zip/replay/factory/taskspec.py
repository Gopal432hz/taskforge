"""TaskSpec: the one reusable strategy's intermediate representation.

A feature-development task generated from a supplied repository.
The LLM stages (intake summarizer, feature proposer, solution drafter)
produce TaskSpec candidates; emit.py and validate.py are deterministic
and repo-agnostic.
"""
import json, re, sys

REQUIRED = ["id", "base_repo", "base_commit", "language", "test_command",
            "feature_title", "requirements", "solution_patch",
            "feature_tests", "regression_tests"]

class SpecError(Exception): pass

def load(path):
    with open(path) as f:
        spec = json.load(f)
    missing = [k for k in REQUIRED if k not in spec]
    if missing:
        raise SpecError(f"missing keys: {missing}")
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,60}", spec["id"]):
        raise SpecError("id must be slug-like")
    if not spec["feature_tests"]:
        raise SpecError("need at least one feature test")
    for t in spec["feature_tests"]:
        inline = "path" in t and "content" in t
        mined = "repo_tests_at" in t and "repo_paths" in t
        if not (inline or mined):
            raise SpecError(f"feature test entry needs path+content or repo_tests_at+repo_paths: {t}")
    for t in spec["regression_tests"]:
        if "repo_path" not in t and not ("path" in t and "content" in t):
            raise SpecError("regression test entry needs repo_path or path+content")
    return spec

if __name__ == "__main__":
    s = load(sys.argv[1])
    print("OK", s["id"], len(s["requirements"]), "requirements")
