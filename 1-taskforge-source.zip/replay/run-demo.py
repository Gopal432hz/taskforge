"""Offline local generate-and-validate walkthrough. Not Docker or hosted evidence."""
from pathlib import Path
import sys,json,subprocess,os,tarfile,shutil,time
ROOT=Path(__file__).resolve().parent
FACTORY=ROOT/'factory'
sys.path.insert(0,str(FACTORY))
import taskspec,emit
start=time.monotonic();events=[]
def log(text):
 print(text,flush=True);events.append({'elapsed_s':round(time.monotonic()-start,3),'text':text})
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--python', default=sys.executable, help='Existing Python interpreter with pytest installed. No install is performed.')
args=parser.parse_args()
source_repo=ROOT/'source-click'
if not source_repo.exists():
 subprocess.run(['git','clone','--quiet',str(ROOT/'click-history.bundle'),str(source_repo)],check=True)
 subprocess.run(['git','-C',str(source_repo),'remote','set-url','origin','https://github.com/pallets/click'],check=True)
spec=taskspec.load(str(ROOT/'reviewed-spec.json'))
spec['base_repo']=str(source_repo)
check=subprocess.run([args.python,'-c','import sys,pytest;print(sys.version.split()[0],pytest.__version__)'],capture_output=True,text=True,check=True)
print('Actual runtime:',check.stdout.strip(),flush=True)

log('TaskForge offline demonstration: reviewed spec -> emitted package -> verifier')
log('Scope: organizer-listed Click upstream, historical pin. Not Docker or organizer acceptance.')
log('Manual step disclosed: active requirements were reviewed against the upstream patch and tests.')
out=ROOT/'live-demo-generated';emit.emit(spec,str(out))
pkg=out/spec['id'];log('Generated fresh package from reviewed TaskSpec. Pinned base: '+spec['base_commit'])
sim=ROOT/'live-demo-runtime'
if sim.exists():shutil.rmtree(sim)
(sim/'app').mkdir(parents=True)
with tarfile.open(pkg/'environment/repo.tar.gz') as t:
 for m in t.getmembers():
  if m.name.startswith('/') or '..' in Path(m.name).parts or m.issym() or m.islnk():raise ValueError('Unsafe tar member')
 t.extractall(sim/'app')
for d in ['tests','solution']:shutil.copytree(pkg/d,sim/d)
(sim/'scratch').mkdir()
s=(pkg/'tests/test.sh').read_text().replace('/logs',str(sim/'logs')).replace('/app',str(sim/'app')).replace('/tests/feature',str(sim/'tests/feature')).replace('/tmp/absent.txt',str(sim/'scratch/absent.txt')).replace('/tmp/orig',str(sim/'scratch/orig'))
(sim/'verifier.sh').write_text(s)
shim=sim/'bin';shim.mkdir()
(shim/'pytest').write_text('#!/bin/sh\nexec '+__import__('shlex').quote(args.python)+' -m pytest \"$@\"\n')
(shim/'pytest').chmod(0o755)
py=shim
env=dict(os.environ,PATH=str(py)+':'+os.environ['PATH'],PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
for state,expected in [('base',{'feature':0,'regression':1,'reward':0}),('patched',{'feature':1,'regression':1,'reward':1})]:
 if state=='patched':
  subprocess.run(['git','apply',str(pkg/'solution/reference.patch')],cwd=sim/'app',check=True)
  log('Applied generated reference patch to independent local runtime.')
 log('Running emitted verifier at '+state+' state. Absolute paths remapped locally, no install/network.')
 p=subprocess.run(['bash',str(sim/'verifier.sh')],env=env,text=True,capture_output=True,timeout=60)
 (sim/(state+'-stdout.txt')).write_text(p.stdout+p.stderr)
 for line in p.stdout.splitlines():
  if ' passed' in line or ' failed' in line or 'reward' in line:log(line)
 actual=json.loads((sim/'logs/verifier/reward.json').read_text())
 if actual!=expected:raise RuntimeError('Unexpected verifier outcome, see raw output')
 log(state.upper()+' expected outcome verified: '+json.dumps(actual))
log('PASS: fresh emission and path-remapped local verification. Selected test suite only.')
log('LIMITS: no Docker image build, no hosted runner, historical repository pin provisional, no publication.')
(ROOT/'live-demo-events.json').write_text(json.dumps(events,indent=2))
