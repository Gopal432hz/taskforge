#!/bin/bash
set -uo pipefail
mkdir -p /logs/verifier
cd /app
feature=0; regression=0
FILES=$(cd /tests/feature && find . -type f | sed 's|^\./||')
: > /tmp/absent.txt; mkdir -p /tmp/orig
for f in $FILES; do if [ -f /app/$f ]; then mkdir -p /tmp/orig/$(dirname $f); cp /app/$f /tmp/orig/$f; else echo $f >> /tmp/absent.txt; fi; done
for f in $FILES; do mkdir -p /app/$(dirname $f); cp /tests/feature/$f /app/$f; done
if PYTHONPATH=/app/src:/app pytest /app/tests/test_basic.py -k 'test_custom_version_option or test_custom_version_option_receives_context' -q; then feature=1; fi
for f in $FILES; do if grep -qxF $f /tmp/absent.txt; then rm -f /app/$f; else cp /tmp/orig/$f /app/$f; fi; done
if PYTHONPATH=/app/src:/app pytest /app/tests/test_basic.py -q; then regression=1; fi
r=0; if [ "$feature" -eq 1 ] && [ "$regression" -eq 1 ]; then r=1; fi
printf '{"feature": %s, "regression": %s, "reward": %s}\n' "$feature" "$regression" "$r" > /logs/verifier/reward.json
cat /logs/verifier/reward.json
