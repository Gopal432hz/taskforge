# TaskForge, finite-strategy prototype

Private review candidate, November25 2026. Not yet an Innodata submission.

TaskForge takes an unmodified local clone of Click8.5.1 at cf19179e8e2fd54c601378cec9e0d21bb12b6fb1 and a declarative catalog of feature strategies. It emits five new-feature exercise packages, including instructions, clean base snapshots, reference patches, feature and regression selectors, proportional grading and Harbor0.25-compatible metadata.

## Scope, without inflated claims

This prototype uses a finite authored catalog, not an open-ended autonomous feature inventor. It supports one pinned Click baseline and five strategies: Duration, typed KeyValue, escaped Delimited sequences, Choice aliases and stepped IntRange. The pipeline automates repeatable packaging and verification; human-written feature strategies and reference implementations are inputs. It does not demonstrate continuous production of arbitrary new tasks. This is a limitation against the organizer's broader factory objective, not a claim of full competition compliance.

## Generate

Requirements: git and Python3.11+.

    git clone --branch 8.5.1 --depth 1 https://github.com/pallets/click.git click-base
    python factory.py --repo click-base --out outputs

The input checkout must remain unmodified. Each task starts from the same real upstream commit. The snapshot does not include future history or the reference solution. Reference code is isolated under solution/.

## Validate on a Docker host

Install Harbor0.25.0 into a Python3.12+ host environment. Each task environment uses Python3.11 and the repository's pytest runner. Docker must be running. No paid model API is needed for nop and oracle agents.

    pip install 'harbor==0.25.0'
    harbor run -p outputs/duration -a nop -k 1 -o runs/duration/nop --no-delete -y
    harbor run -p outputs/duration -a oracle -k 1 -o runs/duration/oracle --no-delete -y

Repeat for all five tasks. A baseline reward must be0, oracle1, existing regressions must pass. Grading awards the fraction of feature tests passing only when no regression fails; collection/environment errors are not valid task failures. Tests require no external credentials or network. The image build fetches Debian/PyPI dependencies.

## Evidence so far

- Two factory generations produce the same55file hashes.
- Harbor0.25.0 Task/TaskConfig parsers accept all five packages; nop/oracle CLI arguments parse in print-config mode.
- Local path-remapped emitted graders give baseline0/oracle1 for each task, with2434normal upstream tests passing,24platform skips and1expected failure.31000stress parametrizations are excluded by upstream default. An extra all-stress run did not finish, so all-stress coverage is not claimed.
- One meaningful wrong-behavior mutant per feature is rejected.
- Partial grading, regression failure and collection-error handling are tested.
- New package Docker builds and actual Harbor nop/oracle execution remain UNVERIFIED. The earlier public three-historical-task Docker pass does not validate this rebuild.

Source and generated artifacts are review candidates. No contest submission, model solve-rate evaluation or organizer acceptance is claimed.

## License

New project code and feature strategy catalog: MIT, see LICENSE. Clean Click snapshots retain BSD-3-Clause, see CLICK-LICENSE.txt and each environment snapshot's LICENSE.txt. No source from Nodstar, Pixis or private customer work is included.
