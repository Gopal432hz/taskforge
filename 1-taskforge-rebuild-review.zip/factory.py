"""Private finite-strategy task factory, not an autonomous feature proposer.
Reads an unmodified Click clone, rejects a wrong baseline or existing feature,
then emits independently isolated new-feature packages from declarative catalog.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tarfile,io,shutil,os,re
BASE_COMMIT='cf19179e8e2fd54c601378cec9e0d21bb12b6fb1'
HERE=Path(__file__).parent
CONTRACTS={
'duration':('Duration value type',['Export click.Duration, a ParamType converting to non-negative integer seconds.','Accept non-negative integer values but reject bool. Parse strings containing one or more integer h/m/s components in that order, with no repeated unit. Each component may exceed59.','Reject negative, fractional, bare-number, out-of-order, repeated-unit and trailing-junk strings with BadParameter.','Work through ordinary click.option conversion; preserve all existing APIs.']),
'key-value':('Typed key=value values',['Export click.KeyValue(value_type=str), a ParamType returning a (key, converted_value) tuple.','Split string input at the FIRST equals. Key must be nonempty, retain whitespace verbatim; empty string values are valid for string type.','Convert the value using Click convert_type(value_type) and propagate BadParameter for invalid typed values. Reject input with no equals or empty key.','Support multiple=True options normally; preserve all existing APIs.']),
'delimited':('Escaped delimited typed sequences',['Export click.Delimited(item_type=str, separator=","), a ParamType returning a tuple of individually converted values.','Separator must be one character and not a backslash, otherwise raise ValueError.','Backslash escapes only the separator or another backslash. Reject trailing backslash or unsupported escape with BadParameter.','Preserve empty fields and whitespace. Convert every field with Click convert_type(item_type), including custom separators. Preserve existing behavior.']),
'choice-aliases':('Canonical aliases for Choice',['Extend click.Choice with optional aliases mapping alias strings to existing canonical choice values.','Reject an alias target outside the canonical choices at construction with ValueError.','Normalize aliases with the same case-sensitivity and Context.token_normalize_func rules as canonical values. Return the canonical original target, not alias.','Canonical choices take precedence when an alias conflicts. Aliases do not appear in metavar help. No aliases must preserve original behavior.']),
'stepped-range':('Stepped IntRange conversion',['Extend click.IntRange with optional step=None. Default None preserves all original behavior.','Non-None step must be a positive integer and not bool. It requires min and is incompatible with clamp, raising ValueError for invalid configurations.','After ordinary range validation, accept only values whose difference from min is a multiple of step, else raise BadParameter. Open bounds still apply and negative anchors are allowed.','Include step in to_info_dict only when configured; preserve all other APIs.'])}
def cmd(args,**kw): return subprocess.run(args,check=True,capture_output=True,**kw).stdout

def main():
 a=argparse.ArgumentParser();a.add_argument('--repo',type=Path,required=True);a.add_argument('--out',type=Path,required=True);args=a.parse_args()
 repo=args.repo.resolve();out=args.out.resolve()
 assert cmd(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==BASE_COMMIT,'unsupported baseline'
 assert not cmd(['git','-C',str(repo),'status','--porcelain'],text=True).strip(),'baseline must be clean'
 catalog=json.loads((HERE/'catalog.json').read_text());out.mkdir(parents=True,exist_ok=True)
 archive=cmd(['git','-C',str(repo),'archive','--format=tar.gz',BASE_COMMIT])
 for spec in catalog:
  name=spec['id'];target=out/name
  if target.exists():shutil.rmtree(target)
  for sub in ['environment','solution','tests']: (target/sub).mkdir(parents=True,exist_ok=True)
  source=(repo/'src/click/types.py').read_text(); init=(repo/'src/click/__init__.py').read_text()
  assert spec['absence_marker'] not in source,'feature already exists'
  files={'src/click/types.py':source+'\n\n'+spec['implementation'],'src/click/__init__.py':init+f'\nfrom .types import {spec["symbol"]} as {spec["symbol"]}\n'}
  patch=''
  import difflib
  for path,new in files.items():
   old=(repo/path).read_text();patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
  (target/'solution/reference.patch').write_text(patch)
  (target/'solution/solve.sh').write_text('#!/bin/bash\nset -euo pipefail\ncd /app\ngit apply /solution/reference.patch\n')
  (target/'environment/repo.tar.gz').write_bytes(archive)
  (target/'environment/Dockerfile').write_text('FROM python:3.11-slim\nRUN apt-get update && apt-get install -y --no-install-recommends git && rm -rf /var/lib/apt/lists/*\nRUN pip install --no-cache-dir "pytest==8.4.2" "flit_core>=3.11,<4"\nWORKDIR /app\nCOPY repo.tar.gz /tmp/repo.tar.gz\nRUN tar xzf /tmp/repo.tar.gz -C /app && rm /tmp/repo.tar.gz\nRUN pip install --no-cache-dir --no-build-isolation -e .\n')
  tests=spec['tests']
  # Existing-behavior probes must not be counted as failing new-feature cases.
  tests=re.sub(r'\ndef test_(plain|old)\(\):[^\n]*\n','\n',tests)
  (target/'tests/test_feature.py').write_text(tests)
  (target/'tests/fail_to_pass.json').write_text(json.dumps(spec['feature_ids'],indent=2))
  (target/'tests/pass_to_pass.json').write_text(json.dumps(spec['regression_ids'],indent=2))
  (target/'tests/grade.py').write_text(GRADER)
  (target/'tests/test.sh').write_text('#!/bin/bash\nset -euo pipefail\ncd /app\nmkdir -p /logs/verifier\nPYTHONPATH=/app/src python /tests/grade.py\n')
  (target/'task.toml').write_text(f'''schema_version = "1.4"
[task]
name = "taskforge/{name}"
authors = [{{name="TaskForge"}}]
[metadata]
base_repo = "https://github.com/pallets/click"
base_commit = "{BASE_COMMIT}"
license = "BSD-3-Clause"
category = "programming"
[verifier]
timeout_sec = 120.0
environment_mode = "shared"
[environment]
network_mode = "no-network"
''')
  title,requirements=CONTRACTS[name]
  (target/'instruction.md').write_text(f'# {title}\n\nThe unmodified repository is at /app, baseline {BASE_COMMIT}.\n\n'+ '\n'.join('- '+r for r in requirements)+'\n\nDo not change shipped tests. Retain all existing behavior.\n')
  for f in ['solution/solve.sh','tests/test.sh']:(target/f).chmod(0o755)
 manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
 (out/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2));print(json.dumps({'tasks':len(catalog),'files':len(manifest),'out':str(out)}))
GRADER='''import subprocess,xml.etree.ElementTree as ET,json,os
from pathlib import Path
root=Path('/logs/verifier')
env=dict(os.environ,PYTHONPATH='/app/src')
def run(args,name):
    result=subprocess.run(['pytest','-q',*args,'--junitxml='+str(root/(name+'.xml'))],env=env)
    tree=ET.parse(root/(name+'.xml'));cases=tree.findall('.//testcase')
    passed=sum(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases)
    return result.returncode,cases,passed
f,fc,fp=run(['/tests/test_feature.py','-o','addopts='],'feature')
r,rc,rp=run(['/app/tests'],'regression')
if f not in (0,1) or r not in (0,1):
    raise RuntimeError('Verifier failed to collect or execute tests; no reward emitted')
reward=fp/len(fc) if fc and r==0 else 0.0
result={'reward':reward,'feature_passed':fp,'feature_total':len(fc),'regression_ok':int(r==0)}
(root/'reward.json').write_text(json.dumps(result));print(json.dumps(result))
'''
if __name__=='__main__':main()
