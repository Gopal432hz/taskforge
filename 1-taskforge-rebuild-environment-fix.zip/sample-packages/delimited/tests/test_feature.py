import click, pytest
def test_ints(): assert click.Delimited(int).convert('1,2,3',None,None)==(1,2,3)
def test_escaped(): assert click.Delimited().convert(r'a\,b,c',None,None)==('a,b','c')
def test_empty(): assert click.Delimited().convert('a,,',None,None)==('a','','')
def test_custom(): assert click.Delimited(int,separator=';').convert('1;2',None,None)==(1,2)
@pytest.mark.parametrize('raw',['x\\','a\\z'])
def test_bad_escape(raw):
    with pytest.raises(click.BadParameter): click.Delimited().convert(raw,None,None)
def test_bad_item():
    with pytest.raises(click.BadParameter): click.Delimited(int).convert('1,b',None,None)
def test_bad_separator():
    with pytest.raises(ValueError): click.Delimited(separator='..')
