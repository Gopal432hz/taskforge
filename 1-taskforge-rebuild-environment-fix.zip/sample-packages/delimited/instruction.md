# Escaped delimited typed sequences

The unmodified repository is at /app, baseline cf19179e8e2fd54c601378cec9e0d21bb12b6fb1.

- Export click.Delimited(item_type=str, separator=","), a ParamType returning a tuple of individually converted values.
- Separator must be one character and not a backslash, otherwise raise ValueError.
- Backslash escapes only the separator or another backslash. Reject trailing backslash or unsupported escape with BadParameter.
- Preserve empty fields and whitespace. Convert every field with Click convert_type(item_type), including custom separators. Preserve existing behavior.

Do not change shipped tests. Retain all existing behavior.
