import click, pytest

def test_alias(): assert click.Choice(['red','blue'],aliases={'r':'red'}).convert('r',None,None)=='red'
def test_casefold(): assert click.Choice(['Red'],False,aliases={'r':'Red'}).convert('R',None,None)=='Red'
def test_canonical_precedence(): assert click.Choice(['red','blue'],aliases={'red':'blue'}).convert('red',None,None)=='red'
def test_invalid_target():
    with pytest.raises(ValueError): click.Choice(['red'],aliases={'r':'green'})
def test_invalid_value():
    with pytest.raises(click.BadParameter): click.Choice(['red'],aliases={'r':'red'}).convert('x',None,None)
def test_help_not_alias():
    t=click.Choice(['red','blue'],aliases={'r':'red'})
    ctx=click.Context(click.Command('x'));p=click.Option(['--color'],type=t)
    assert t.get_metavar(p,ctx)=='[red|blue]'
def test_normalizer():
    ctx=click.Context(click.Command('x'),token_normalize_func=str.lower)
    assert click.Choice(['red'],aliases={'R':'red'}).convert('r',None,ctx)=='red'
