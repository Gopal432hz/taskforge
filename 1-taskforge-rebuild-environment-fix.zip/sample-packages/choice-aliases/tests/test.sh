#!/bin/bash
set -euo pipefail
cd /app
mkdir -p /logs/verifier
PYTHONPATH=/app/src python /tests/grade.py
