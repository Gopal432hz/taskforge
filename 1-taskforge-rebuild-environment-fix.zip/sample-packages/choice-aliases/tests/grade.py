import subprocess,xml.etree.ElementTree as ET,json,os
from pathlib import Path
root=Path('/logs/verifier')
env=dict(os.environ,PYTHONPATH='/app/src')
def run(args,name):
    result=subprocess.run(['pytest','-q',*args,'--junitxml='+str(root/(name+'.xml'))],env=env)
    tree=ET.parse(root/(name+'.xml'));cases=tree.findall('.//testcase')
    passed=sum(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases)
    return result.returncode,cases,passed
f,fc,fp=run(['/tests/test_feature.py','-o','addopts='],'feature')
r,rc,rp=run(['/app/tests'],'regression')
if f not in (0,1) or r not in (0,1):
    raise RuntimeError('Verifier failed to collect or execute tests; no reward emitted')
reward=fp/len(fc) if fc and r==0 else 0.0
result={'reward':reward,'feature_passed':fp,'feature_total':len(fc),'regression_ok':int(r==0)}
(root/'reward.json').write_text(json.dumps(result));print(json.dumps(result))
