# Canonical aliases for Choice

The unmodified repository is at /app, baseline cf19179e8e2fd54c601378cec9e0d21bb12b6fb1.

- Extend click.Choice with optional aliases mapping alias strings to existing canonical choice values.
- Reject an alias target outside the canonical choices at construction with ValueError.
- Normalize aliases with the same case-sensitivity and Context.token_normalize_func rules as canonical values. Return the canonical original target, not alias.
- Canonical choices take precedence when an alias conflicts. Aliases do not appear in metavar help. No aliases must preserve original behavior.

Do not change shipped tests. Retain all existing behavior.
