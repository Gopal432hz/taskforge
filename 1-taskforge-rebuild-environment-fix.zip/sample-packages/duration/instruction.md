# Duration value type

The unmodified repository is at /app, baseline cf19179e8e2fd54c601378cec9e0d21bb12b6fb1.

- Export click.Duration, a ParamType converting to non-negative integer seconds.
- Accept non-negative integer values but reject bool. Parse strings containing one or more integer h/m/s components in that order, with no repeated unit. Each component may exceed59.
- Reject negative, fractional, bare-number, out-of-order, repeated-unit and trailing-junk strings with BadParameter.
- Work through ordinary click.option conversion; preserve all existing APIs.

Do not change shipped tests. Retain all existing behavior.
