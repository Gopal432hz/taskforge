import click, pytest
@pytest.mark.parametrize("raw,out", [("1h30m",5400),("2m3s",123),("0s",0),(12,12),("100m",6000)])
def test_valid(raw,out): assert click.Duration().convert(raw,None,None)==out
@pytest.mark.parametrize("raw",["", "1m1h", "1m2m", "-2s", "1.5h", "12",True])
def test_invalid(raw):
    with pytest.raises(click.BadParameter): click.Duration().convert(raw,None,None)
def test_cli():
    @click.command()
    @click.option('--timeout', type=click.Duration())
    def cli(timeout): click.echo(timeout)
    from click.testing import CliRunner
    r=CliRunner().invoke(cli,['--timeout','1h2s']); assert r.exit_code==0 and r.output=='3602\n'
