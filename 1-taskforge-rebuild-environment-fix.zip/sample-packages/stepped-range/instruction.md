# Stepped IntRange conversion

The unmodified repository is at /app, baseline cf19179e8e2fd54c601378cec9e0d21bb12b6fb1.

- Extend click.IntRange with optional step=None. Default None preserves all original behavior.
- Non-None step must be a positive integer and not bool. It requires min and is incompatible with clamp, raising ValueError for invalid configurations.
- After ordinary range validation, accept only values whose difference from min is a multiple of step, else raise BadParameter. Open bounds still apply and negative anchors are allowed.
- Include step in to_info_dict only when configured; preserve all other APIs.

Do not change shipped tests. Retain all existing behavior.
