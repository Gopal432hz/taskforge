import click, pytest
@pytest.mark.parametrize('raw,out',[('2',2),('5',5),('8',8)])
def test_valid(raw,out): assert click.IntRange(2,10,step=3).convert(raw,None,None)==out
@pytest.mark.parametrize('raw',['1','3','11'])
def test_invalid(raw):
    with pytest.raises(click.BadParameter): click.IntRange(2,10,step=3).convert(raw,None,None)
def test_open_min():
    with pytest.raises(click.BadParameter): click.IntRange(2,10,min_open=True,step=3).convert('2',None,None)
def test_negative_anchor(): assert click.IntRange(-5,5,step=3).convert('1',None,None)==1
@pytest.mark.parametrize('kwargs',[{'step':0,'min':0},{'step':True,'min':0},{'step':2},{'step':2,'min':0,'clamp':True}])
def test_config(kwargs):
    with pytest.raises(ValueError): click.IntRange(**kwargs)
def test_metadata(): assert click.IntRange(0,10,step=2).to_info_dict()['step']==2
