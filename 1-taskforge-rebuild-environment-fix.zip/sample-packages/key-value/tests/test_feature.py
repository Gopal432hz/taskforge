import click, pytest
def test_integer(): assert click.KeyValue(int).convert('jobs=12',None,None)==('jobs',12)
def test_extra_equals(): assert click.KeyValue().convert('token=a=b',None,None)==('token','a=b')
def test_empty_value(): assert click.KeyValue().convert('x=',None,None)==('x','')
@pytest.mark.parametrize('raw',['x','=a',''])
def test_invalid(raw):
    with pytest.raises(click.BadParameter): click.KeyValue().convert(raw,None,None)
def test_nested_bad():
    with pytest.raises(click.BadParameter): click.KeyValue(int).convert('x=no',None,None)
def test_multiple():
    @click.command()
    @click.option('--set', 'values',type=click.KeyValue(int),multiple=True)
    def cli(values): click.echo(repr(values))
    from click.testing import CliRunner
    r=CliRunner().invoke(cli,['--set','x=1','--set','y=2']); assert r.exit_code==0 and "('y', 2)" in r.output
