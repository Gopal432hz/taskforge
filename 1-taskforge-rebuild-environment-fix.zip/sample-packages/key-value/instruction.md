# Typed key=value values

The unmodified repository is at /app, baseline cf19179e8e2fd54c601378cec9e0d21bb12b6fb1.

- Export click.KeyValue(value_type=str), a ParamType returning a (key, converted_value) tuple.
- Split string input at the FIRST equals. Key must be nonempty, retain whitespace verbatim; empty string values are valid for string type.
- Convert the value using Click convert_type(value_type) and propagate BadParameter for invalid typed values. Reject input with no equals or empty key.
- Support multiple=True options normally; preserve all existing APIs.

Do not change shipped tests. Retain all existing behavior.
