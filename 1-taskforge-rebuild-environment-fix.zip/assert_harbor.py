import json,sys
from pathlib import Path
from harbor.models.trial.result import TrialResult
root=Path(sys.argv[1]);agent=sys.argv[2];task=sys.argv[3]
trials=[]
for path in root.rglob('result.json'):
    raw=json.loads(path.read_text())
    if isinstance(raw,dict) and 'trial_name' in raw and 'agent_info' in raw:
        trial=TrialResult.model_validate(raw)
        trials.append((path,trial))
assert len(trials)==1, f'Expected exactly one trial result, found {len(trials)}'
path,trial=trials[0]
assert trial.exception_info is None, trial.exception_info
assert trial.reward_valid, 'Reward invalid or missing'
rewards=trial.verifier_result.rewards
expected=1.0 if agent=='oracle' else 0.0
assert rewards['reward']==expected, rewards
assert rewards['regression_ok']==1, rewards
assert rewards['feature_total']>0, rewards
print(json.dumps({'task':task,'agent':agent,'trial_name':trial.trial_name,'rewards':rewards,'result':str(path)}))
